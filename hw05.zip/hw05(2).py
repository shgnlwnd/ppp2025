n = int(input('삼각형 별을 몇개 그릴까?'))
for i in range(1, n + 1):
    print('*' * i)