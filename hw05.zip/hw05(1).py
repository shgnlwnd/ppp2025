def gugudan(dan):
    
    for i in range(9):
        print(f'{dan} * {i+1} = {dan * (i+1)}')

dan = int(input('몇단인지 입력하세요?'))

if __name__=='__main__':
    gugudan(dan)



