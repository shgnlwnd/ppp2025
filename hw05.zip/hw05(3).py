import math

for i in range(91):

    a = math.radians(i)
    print(f'라디안 {i} = {a}')
    print(f"sin{i}= ",math.sin(a))
    print(f"cos{i}= ",math.cos(a))
    print(f"tan{i}= ",math.tan(a))
