def sum_n(n):
    total = 0
    for i in range(n):
        x= i + 1
        total = total + x
    print(total)


n = int(input('n값을 입력하세요?'))
if __name__=='__main__':
    sum_n(n)